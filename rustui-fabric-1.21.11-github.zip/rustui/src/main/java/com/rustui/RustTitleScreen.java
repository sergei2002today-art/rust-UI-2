package com.rustui;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.options.OptionsScreen;
import net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen;
import net.minecraft.client.gui.screens.worldselection.SelectWorldScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Util;

public class RustTitleScreen extends Screen {
    private static final int BASE_X = 18;
    private final long openTime = Util.getMillis();
    private final List<RustButton> buttons = new ArrayList<>();

    public RustTitleScreen() {
        super(Component.translatable("narrator.screen.title"));
    }

    private void add(int y, Component label, Button.OnPress press) {
        RustButton b = new RustButton(BASE_X, y, 176, 18, label, press);
        buttons.add(b);
        addRenderableWidget(b);
    }

    @Override
    protected void init() {
        buttons.clear();
        int h = 18, step = h + 2, gap = 12;
        int y = (int) (this.height * 0.34);
        add(y, Component.translatable("menu.singleplayer"), b -> minecraft.setScreen(new SelectWorldScreen(this)));
        y += step + gap;
        add(y, Component.translatable("menu.multiplayer"), b -> minecraft.setScreen(new JoinMultiplayerScreen(this)));
        y += step + gap;
        add(y, Component.translatable("menu.options"), b -> minecraft.setScreen(new OptionsScreen(this, minecraft.options)));
        y += step + gap;
        add(y, Component.translatable("menu.quit"), b -> minecraft.stop());
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        long el = Util.getMillis() - openTime;
        for (int i = 0; i < buttons.size(); i++) {
            float e = RustTheme.ease((el - 250 - i * 110) / 500f);
            RustButton b = buttons.get(i);
            b.appear = e;
            b.setX(BASE_X - (int) (36 * (1f - e)));
        }
        super.render(g, mouseX, mouseY, delta);
    }

    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float delta) {
        long el = Util.getMillis() - openTime;
        RustTheme.drawBackground(g, width, height);
        RustTheme.drawLeftShade(g, height);
        // y=52 keeps the logo below the launcher's on-screen Esc button
        RustTheme.drawLogo(g, font, 28, 52, RustTheme.ease(el / 700f));
        float v = RustTheme.ease((el - 600) / 600f);
        if (v > 0.04f) {
            g.drawString(font, Component.literal("Minecraft " + net.minecraft.SharedConstants.getCurrentVersion().name()),
                    28, height - 16, RustTheme.a(0x9A9A9A, v));
        }
        float black = 1f - RustTheme.ease(el / 450f);
        if (black > 0.01f) g.fill(0, 0, width, height, RustTheme.a(0x000000, black));
    }

    @Override
    public boolean shouldCloseOnEsc() { return false; }
}
