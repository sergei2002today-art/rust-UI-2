package com.rustui;

import java.util.List;
import java.util.Locale;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Util;

public final class RustTheme {
    public static final int RED      = 0xFFCD412B;
    public static final int RED_HOT  = 0xFFE0553B;
    public static final int TEXT     = 0xFFE6E6E6;
    public static final int TEXT_DIM = 0xFF9A9A9A;
    public static final int WHITE    = 0xFFFFFFFF;
    public static final int BAR_BG   = 0xFF0A0A0A;

    private static final String[] TIPS = {
        "Совет: держи оружие заряженным, а друзей поближе.",
        "Совет: ночью в лесу лучше иметь факел и план отступления.",
        "Совет: не складывай все ресурсы в один сундук.",
        "Совет: тихий шаг и приседание помогают подобраться незаметно.",
        "Совет: пока ты читаешь это, мир уже строит себя вокруг тебя.",
        "Совет: у любого хорошего убежища должно быть два выхода."
    };

    private static long loadStart, lastLoad;
    private static float cancelHover;
    private static long cancelLast;

    private RustTheme() {}

    // ---------- helpers ----------
    public static Component bold(String s) {
        return Component.literal(s.toUpperCase(Locale.ROOT)).withStyle(st -> st.withBold(true));
    }

    public static float ease(float t) {
        t = Math.max(0f, Math.min(1f, t));
        float u = 1f - t;
        return 1f - u * u * u;
    }

    /** rgb (no alpha) + alpha 0..1 -> ARGB */
    public static int a(int rgb, float alpha) {
        int al = (int) (Math.max(0f, Math.min(1f, alpha)) * 255f);
        return (al << 24) | (rgb & 0xFFFFFF);
    }

    // ---------- background ----------
    private static void fogBand(GuiGraphics g, int x, int y1, int bandW, int y2, int maxAlpha) {
        int n = 16;
        int sw = Math.max(1, bandW / n);
        for (int k = 0; k < n; k++) {
            float env = (float) Math.sin(Math.PI * (k + 0.5) / n);
            int al = (int) (maxAlpha * env);
            g.fillGradient(x + k * sw, y1, x + (k + 1) * sw, y2, (al << 24) | 0xFFFFFF, 0x00FFFFFF);
        }
    }

    public static void drawEmbers(GuiGraphics g, int w, int h) {
        double t = Util.getMillis() / 1000.0;
        double cycle = h + 30;
        for (int i = 0; i < 40; i++) {
            double fx = (i * 0.6180339887) % 1.0;
            double speed = 10 + (i % 7) * 4;
            double phase = (i * 0.37) % 1.0;
            double y = h + 10 - ((t * speed + phase * cycle) % cycle);
            double x = fx * w + Math.sin(t * 0.7 + i) * 12;
            float life = (float) Math.min(1.0, Math.max(0.0, (h + 10 - y) / cycle));
            float alpha = (float) Math.sin(Math.PI * life) * 0.85f;
            int s = (i % 3 == 0) ? 2 : 1;
            int col = (i % 4 == 0) ? 0xFF8A2B : 0xCD412B;
            g.fill((int) x, (int) y, (int) x + s, (int) y + s, a(col, alpha));
        }
    }

    /** Moody backdrop: gradient, drifting fog, embers, vignette. */
    public static void drawBackground(GuiGraphics g, int w, int h) {
        double t = Util.getMillis() / 1000.0;
        g.fillGradient(0, 0, w, h, 0xFF232B31, 0xFF0A0C0A);
        int x1 = (int) ((Math.sin(t * 0.12) * 0.25 - 0.05) * w);
        fogBand(g, x1, (int) (h * 0.30), (int) (w * 0.9), (int) (h * 0.85), 0x14);
        int x2 = (int) ((Math.cos(t * 0.09) * 0.25 + 0.25) * w);
        fogBand(g, x2, (int) (h * 0.45), (int) (w * 0.8), h, 0x0E);
        drawEmbers(g, w, h);
        for (int i = 0; i < 40; i++) {
            int c = ((int) (0xB0 * (1f - i / 40f))) << 24;
            g.fill(i * 3, 0, i * 3 + 3, h, c);
            g.fill(w - i * 3 - 3, 0, w - i * 3, h, c);
        }
    }

    public static void drawLeftShade(GuiGraphics g, int h) {
        for (int i = 0; i < 50; i++) {
            int c = ((int) (0xC8 * (1f - i / 50f))) << 24;
            g.fill(i * 6, 0, i * 6 + 6, h, c);
        }
    }

    public static void drawLogo(GuiGraphics g, Font font, int x, int y, float appear) {
        if (appear < 0.04f) return;
        x -= (int) (20 * (1f - appear));
        double t = Util.getMillis() / 1000.0;
        float pulse = (float) (0.88 + 0.12 * Math.sin(t * 2.2));
        int c = a(0xCD412B, appear * pulse);
        g.fill(x, y, x + 7, y + 7, c);
        g.fill(x + 9, y, x + 16, y + 7, c);
        g.fill(x, y + 9, x + 7, y + 16, c);
        g.fill(x + 9, y + 9, x + 16, y + 16, c);
        g.drawString(font, bold("Rust"), x + 22, y + 4, a(0xFFFFFF, appear));
    }

    // ---------- loading screen ----------
    private static void drawLoadingBar(GuiGraphics g, int w, int h, long el) {
        int barH = 4, y = h - barH;
        g.fill(0, y, w, h, BAR_BG);
        float p = (el % 2400L) / 2400f;
        float e = p * p * (3f - 2f * p);
        int head = (int) (e * (w + 200));
        for (int k = 0; k < 40; k++) {
            int x0 = head - k * 6 - 6;
            int x1 = x0 + 6;
            if (x1 <= 0 || x0 >= w) continue;
            int c = a(k == 0 ? 0xE0553B : 0xCD412B, 1f - k / 40f);
            g.fill(Math.max(0, x0), y, Math.min(w, x1), h, c);
        }
    }

    public static void drawLoading(GuiGraphics g, Font font, int w, int h, String title, String info,
                                   Component sub, List<? extends GuiEventListener> children, int mx, int my) {
        long now = Util.getMillis();
        if (now - lastLoad > 800L) loadStart = now;
        lastLoad = now;
        long el = now - loadStart;

        drawBackground(g, w, h);
        g.fillGradient(0, h - 120, w, h, 0x00000000, 0xF2000000);

        float in = ease(el / 600f);
        int slide = (int) (40 * (1f - in));
        if (in > 0.04f) g.drawString(font, bold(title), 28 - slide, h - 96, a(0xFFFFFF, in));
        float in2 = ease((el - 150) / 600f);
        if (in2 > 0.04f) g.drawString(font, Component.literal(info), 28 - slide, h - 82, a(0x9A9A9A, in2));

        // rotating tips with fade
        long period = 4500L;
        int idx = (int) ((el / period) % TIPS.length);
        long ph = el % period;
        float fade = Math.min(1f, Math.min(ph / 400f, (period - ph) / 400f)) * in;
        double t = now / 1000.0;
        float badge = (float) (0.75 + 0.25 * Math.sin(t * 3.0));
        g.fill(28, h - 41, 38, h - 31, a(0xFFFFFF, badge * in));
        if (in > 0.04f) g.drawString(font, Component.literal("i"), 32, h - 40, 0xFF000000);
        if (fade > 0.04f) g.drawString(font, Component.literal(TIPS[idx]), 44, h - 40, a(0x9A9A9A, fade));

        // LOADING block with animated dots
        String dots = ".".repeat((int) ((now / 400L) % 4));
        Component full = bold("Загрузка...");
        int lx = w - 24 - font.width(full);
        g.drawString(font, bold("Загрузка" + dots), lx, h - 46, WHITE);
        g.drawString(font, sub, w - 24 - font.width(sub), h - 34, TEXT_DIM);

        // cancel button with eased hover
        for (GuiEventListener c : children) {
            if (c instanceof AbstractWidget wd) {
                wd.setWidth(96);
                wd.setX(w - 24 - 140 - 12 - 96);
                wd.setY(h - 50);
                int x = wd.getX(), y = wd.getY(), bw = wd.getWidth(), bh = wd.getHeight();
                boolean hot = mx >= x && mx < x + bw && my >= y && my < y + bh;
                float dt = cancelLast == 0 ? 16f : Math.min(100f, now - cancelLast);
                cancelLast = now;
                cancelHover += ((hot ? 1f : 0f) - cancelHover) * Math.min(1f, dt / 80f);
                g.fill(x, y, x + bw, y + bh, RED);
                g.fill(x, y, x + (int) (bw * cancelHover), y + bh, RED_HOT);
                Component label = bold(wd.getMessage().getString());
                g.drawString(font, label, x + (bw - font.width(label)) / 2, y + (bh - 8) / 2, WHITE);
            }
        }

        drawLoadingBar(g, w, h, el);

        float black = 1f - ease(el / 500f);
        if (black > 0.01f) g.fill(0, 0, w, h, a(0x000000, black));
    }
}
