package com.rustui.mixin;

import com.rustui.RustTheme;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.ConnectScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ConnectScreen.class)
public abstract class ConnectScreenMixin extends Screen {
    protected ConnectScreenMixin(Component t) { super(t); }

    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void rustui$render(GuiGraphics g, int mx, int my, float delta, CallbackInfo ci) {
        ServerData sd = Minecraft.getInstance().getCurrentServer();
        String title = (sd != null && sd.name != null && !sd.name.isEmpty())
                ? sd.name : Component.translatable("connect.connecting").getString();
        String info = sd != null && sd.ip != null ? sd.ip : "";
        RustTheme.drawLoading(g, this.font, this.width, this.height, title, info,
                Component.translatable("connect.connecting"), this.children(), mx, my);
        ci.cancel();
    }
}
