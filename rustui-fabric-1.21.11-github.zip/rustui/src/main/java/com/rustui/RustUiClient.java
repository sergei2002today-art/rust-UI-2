package com.rustui;

import net.fabricmc.api.ClientModInitializer;

public class RustUiClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {}
}
